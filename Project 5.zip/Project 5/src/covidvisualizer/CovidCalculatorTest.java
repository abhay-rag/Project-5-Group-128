package covidvisualizer;

public class CovidCalculatorTest {
    
    private CovidCalculator covidCalculator;
    
    public void setUp() {
        State[] states = new State[State.NUM_STATES];
    }
    
    public void testGetAllStates() {
        
    }
    
    public void testOutput() {
        
    }
}
